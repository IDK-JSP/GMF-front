import { RecipeType } from "./RecipeType";

export interface SearchReturnType {
  ingredients: number[];
  recipes: RecipeType[];
}
