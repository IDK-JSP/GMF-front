export interface LoginFormType {
    email: string
    password: string
}