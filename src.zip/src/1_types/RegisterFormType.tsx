export interface RegisterFormType {
    email: string;
    password: string;
    confirmPassword: string;
}