export interface RecipeIngredientType {
  ingredient_name: string;
  quantity: number;
  measurement: string;
  diet?: string;
}
