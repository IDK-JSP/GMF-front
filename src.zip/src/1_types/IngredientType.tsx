export interface IngredientType {
    "id_ingredient" : number,
    "name" : string,
    "content" : string,
    "createTime"? : string,
    "updateTime"? : string,
}
