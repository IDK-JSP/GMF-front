export interface RecipeStageType {
  stage: number;
  id_recipe: number;
  content: string;
}
