export interface RecipeOpinionsType {
  id_recipe: number;
  email: string;
  rate: number;
  comment?: string;
}
