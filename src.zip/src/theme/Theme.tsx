import {FC} from 'react';

const Theme: FC<{}> = ({}) => {
    return (
        <>

        </>
    );
};

export default Theme;
