import {FC} from 'react';
import "../../styles/footer.css";

const Footer: FC<{}> = ({}) => {
    return (
        <div className="footer">
                Footer du site
        </div>
    );
};

export default Footer;
