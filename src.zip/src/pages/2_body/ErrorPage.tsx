import {FC} from 'react';

const ErrorPage: FC<{}> = ({}) => {
    return (
        <>
            <h3>Y a une erreur là mon reuf</h3>
        </>
    );
};

export default ErrorPage;
