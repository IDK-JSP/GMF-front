import {FC} from 'react';

const CategoryList: FC<{}> = ({}) => {
    return (
        <>

        </>
    );
};

export default CategoryList;
