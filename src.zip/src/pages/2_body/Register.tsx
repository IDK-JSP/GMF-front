import {FC} from 'react';

const Register: FC<{}> = ({}) => {
    return (
        <>

        </>
    );
};

export default Register;
