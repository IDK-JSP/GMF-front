import {FC} from 'react';

const Settings: FC<{}> = ({}) => {
    return (
        <>
            Settings
        </>
    );
};

export default Settings;
