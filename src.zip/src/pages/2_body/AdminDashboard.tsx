import { FC } from "react";

const AdminDashboard: FC<{}> = ({}) => {
  return <></>;
};

export default AdminDashboard;
