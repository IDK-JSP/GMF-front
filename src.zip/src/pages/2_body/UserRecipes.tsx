import {FC} from 'react';

const UserRecipes: FC<{}> = ({}) => {
    return (
        <>
            UserRecipe
        </>
    );
};

export default UserRecipes;
