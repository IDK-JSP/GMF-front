import {FC} from 'react';

const Header: FC<{}> = ({}) => {
    return (
        <>

        </>
    );
};

export default Header;
